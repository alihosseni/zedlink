# [BDReborn](http://yon.ir/V9b5)
* **Install Bot**
`````sh
yon.ir/V9b5
`````
